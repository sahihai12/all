const cacheName = 'v1.2'
cacheAssets = [
    'index.html',
    'style.css',
    'app.js',
    'https://fonts.googleapis.com/css2?family=Nunito+Sans&display=swap',
    'https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css',
    'https://code.jquery.com/jquery-3.6.0.min.js',
    'https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.bundle.min.js'
]

// Install service worker
self.addEventListener('install', (e) => {
    console.log('Service Worker: Installed');
    e.waitUntil(
      caches
        .open(cacheName)
        .then(cache => {
          console.log('Service Worker: Caching Files');
          cache.addAll(cacheAssets);
        })
        .then(() => self.skipWaiting())
    );
  });
  
  // Activate the service worker
  self.addEventListener('activate', (e) => {
    console.log('Service Worker: Activated');
  
    // Remove old caches
    e.waitUntil(
      caches.keys().then(cacheNames => {
        return Promise.all(
          // look at all the cacheNames
          cacheNames.map(cache => {
            // if the current cache !== cacheName then delete it
            if (cache !== cacheName) {
              console.log('Service Worker: Clearing Old Cache');
              return caches.delete(cache);
            }
          })
        )
      })
    );
  
  });
  
  // listen for fetch event (HTTP request)
  self.addEventListener('fetch', (e) => {
    console.log('Service Worker: Fetching');
    // Offline first
    e.respondWith(
      // are the files requested in the cache already?
      caches.match(e.request).then(cachedResponse => {
        // if yes, then serve files from cache
        if (cachedResponse) {
          console.log('Found in cache!');
          return cachedResponse;
        }
        // else do an HTTP request to the server
        return fetch(e.request);
      })
    )
  });
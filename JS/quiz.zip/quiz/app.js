const startBtn  = document.querySelector(`.startQuizBtn`)
const mainDiv  = document.querySelector(`.main`)
const quizBoard = document.querySelector(`.quizBoard`)
const questionDiv = document.querySelector(`.question`)
const timerDiv = document.querySelector(`.timer`)
const answerList = document.querySelector(`.answerList`)
const answerBtn = document.querySelector(`.submitAnswer`)
const resultDiv = document.querySelector(`.quizResult`)
const result = document.querySelector(`.resultBody`)
const percentage = document.querySelector(`.percentage p`)
const ratio = document.querySelector(`.ratioQA p`)
const timeTaken = document.querySelector(`.timeTaken p`)

const questions = [
    {
        question: "what's the full form of RAM:",
        answer: "Random Access Memory",
        options: [
            "Real Accessory Model",
            "Random Access Memory",
            "Random Access Model",
            "Realtime Access Memory"
        ]
    },
    {
        question: "who's the Current president of USA:",
        answer: "Donald Trump",
        options: [
            "George Bush",
            "Obama",
            "Donald Trump",
            "Jon Doe"
        ]
    },
    {
        question: "Who's the owner of Apple Co.:",
        answer: "Steve Jobs",
        options: [
            "Mark Zuckerberg",
            "Jack Ma",
            "Jan Koum",
            "Steve Jobs"
        ]
    },
    {
        question: "Who's the founder of facebook:",
        answer: "Mark Zuckerberg",
        options: [
            "Mark Zuckerberg",
            "Jack Ma",
            "Jan Koum",
            "Steve Jobs"
        ]
    },
    {
        question: "Who's the Co-Founder of Google:",
        answer: "Jan Koum",
        options: [
            "Mark Zuckerberg",
            "Jack Ma",
            "Jan Koum",
            "Steve Jobs"
        ]
    },
]

let nextQues = false

let questionSet = 0

let questionAttemps = []

let minutes = 0

let seconds = 0

let formattedMinutes = 0

let formattedSeconds = 0

function showQuestionDiv(){
    mainDiv.style.display = `none`
    quizBoard.style.display = `flex`
    showQuestions()
    interval = setInterval(function(){
        if(seconds<59) seconds++
        else{
            seconds=0
            if(minutes<59) minutes++
            else{
                minutes=0
                clearInterval(interval)
            }
        }
        formattedSeconds = seconds<10 ? `0${seconds}` : seconds
        formattedMinutes = minutes<10 ? `0${minutes}` : minutes
        timerDiv.innerHTML = `${formattedMinutes}:${formattedSeconds}`
    }, 1000)
}

function showQuestions(){
    const currentQuestion = questions[questionSet]
    questionDiv.textContent = `Q${questionSet+1} ${currentQuestion.question}`
    currentQuestion.options.forEach((list)=>{
        const el = `<li class="answer"> ${list} </li>`
        answerList.insertAdjacentHTML(`afterbegin`,el)
    })
    getAnswer()
}

function getAnswer(){
    const answerDiv = document.querySelectorAll(`.answer`)
    
    function removeActiveAnswers(){
        answerDiv.forEach((item)=>{
            item.classList.remove(`activeAnswer`)
        })
    }

    answerDiv.forEach((item)=>{
        item.addEventListener(`click`,function(el){
            removeActiveAnswers()
            item.classList.add(`activeAnswer`)
            answerBtn.style.display = `block`
        })
    })
}

function previousAnswersRemove(){
    answerList.innerHTML = ''
}

function nextQuestion(){
    const answerSet = {
        question : questions[questionSet].question,
        answer : document.querySelector(`.activeAnswer`).innerHTML.trim(),
        rightAnswer : questions[questionSet].answer
    }
    questionAttemps.push(answerSet)
    if(questionSet < questions.length-1){
        previousAnswersRemove()
        questionSet+=1
        showQuestions()
    }else{
        showResult();
    }
}

function showResult(){
    console.log(interval);
    clearInterval(interval)
    let a
    c = 0
    questionAttemps.forEach((res,i)=>{
        if(res.answer === res.rightAnswer){a ="Correct"; c += 1}else{ a ="Wrong"}
        const item = `<div class="resultDiv"> <p>Q${i+1}</p> <p>${a}</p> </div>`
        result.insertAdjacentHTML(`beforeend`,item)
    })
    p = (c/questions.length)*100
    percentage.textContent = p
    ratio.textContent = `${c}/${questions.length}`
    timeTaken.textContent = `${formattedMinutes}:${formattedSeconds}  `  
    quizBoard.style.display = `none`
    resultDiv.style.display = `block`
}

startBtn.addEventListener(`click`,showQuestionDiv)
answerBtn.addEventListener(`click`,nextQuestion)

if('serviceWorker' in navigator){
    navigator.serviceWorker.register('sw.js')
    .then(function(){
        console.log(`Service Worker is Registered`);
    })
    .catch(err =>{
        console.log(`Error Registering Service Worker ${err}`);
    })
}

